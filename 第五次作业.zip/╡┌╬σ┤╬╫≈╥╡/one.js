function outerFunc() {
  let outerVar = 'I am outside!';
  function innerFunc() {
  console.log(outerVar);
  }
  return innerFunc; }
 const myInnerFunc = outerFunc();
 myInnerFunc();